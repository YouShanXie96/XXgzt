'use strict';

/**
 * 上品库 · 复刻老软件选品池的四个弹窗
 *
 * REA 依据（beta.268 renderer/assets/index-BAFOuonK.js 与 main 模块）：
 *  ① 自动上架 / 上传到店铺：目标店铺多选、自动上架（放进仓库·不立即上架）、店铺分类、
 *     上架价格（同行价 × 倍数 减 金额）、蓝色提示、进度 N/M·成功·失败、深色执行日志、
 *     「没入仓、可以接着处理的任务」+ 打开店铺窗口 / 继续入仓、停止队列 / 后台运行 / 追加上架。
 *  ② 上品记录：累计成功/失败、总览 / 失败记录 Tab、搜索、失败卡片（已修复、失败码+原因、
 *     完整原因 / 复制排查信息）、分页；失败记录里也能手动打开店铺窗口继续处理。
 *  ③ 表单填写窗口：顶部编辑中/基线信息标签、左侧分节导航、右侧字段表单、右侧手机预览、
 *     底部取消 / 保存 / 打开店铺窗口 / 我已改好，继续。
 *  ④ 类目面板：类目路径 + ID + 采集、类目来源店铺、刷新、按名搜叶子类目、三级级联、
 *     「请选到最后一级（叶子类目）才能保存」+ 保存类目。
 *
 * 全部走新软件自己的 selectionpool.* 接口，不接老软件运行时、不出现老软件名称。
 */

(() => {
  const FORM_SECTIONS = [
    { id: 'basic', label: '基本信息 / 类目属性', required: true },
    { id: 'qualification', label: '商品资质', required: true },
    { id: 'spec', label: '规格与类目及规格', required: false },
    { id: 'desc', label: '图文描述', required: false },
    { id: 'sku', label: 'SKU 信息', required: false },
    { id: 'sales', label: '销售信息', required: false },
    { id: 'pay', label: '支付信息', required: false },
    { id: 'logistics', label: '物流与售后', required: false },
  ];

  const TIPS = '勾选「自动上架」后，按选品的类目和参数一件件填好发布页，放进店铺仓库（不会直接开卖）。店铺品牌用各店铺在该类目的授权品牌；上架遇验证码时弹出店铺窗口并暂停，请人工完成验证，不会自动重传或重复提交。不勾选则只记录任务。';

  function create(deps) {
    const { api, esc, svg, toast, render, state, data, reload, openShopPage, registerManualFixes, button, navigate } = deps;

    // 详情缓存：同一件商品 2 分钟内再打开直接用（老软件也是缓存后秒开）
    const detailCache = new Map();

    const ui = {
      name: '', busy: false, message: '',
      shelf: { itemIds: [], shops: new Set(), config: null, queue: null, logs: [], resume: null, shopCats: {}, logAll: false },
      pub: { tab: 'failures', keyword: '', page: 1, size: 6, data: null, expanded: '', resume: null, shelfRecords: [], itemId: 0 },
      form: { itemId: 0, detail: null, section: 'basic', fields: [], categoryId: '', categoryPath: '', warehouseItemId: '', message: '' },
      detail: { itemId: 0, tab: 'overview', data: null, busy: false, error: '', imageIndex: 0 },
      cat: { itemId: 0, profileId: '', keyword: '', levels: [[], [], []], ids: ['', '', ''], picked: null, hits: [], busy: false, message: '', productId: '', personal: null },
      logs: { runs: [], runId: '', busy: false, error: '' },
    };

    const shops = () => (data().shopStates?.stores || []);
    const loggedIn = () => (data().shopStates?.loggedIn || []);
    const queue = () => data().queue || ui.shelf.queue || {};
    const resume = () => ui.shelf.resume || ui.pub.resume || data().resumeTasks || { items: [], note: '', tail: '' };
    const pub = () => ui.pub.data || data().publication || { rows: [], totals: { success: 0, failed: 0 }, total: 0, page: 1, pages: 1 };
    const cfg = () => ui.shelf.config || data().autoShelfConfig || {};

    const short = (value, n = 30) => {
      const t = String(value || '');
      return t.length > n ? `${t.slice(0, n)}…` : t;
    };
    const time = value => {
      const text = String(value || '');
      if (!text) return '—';
      const d = new Date(text);
      if (Number.isNaN(d.getTime())) return text.slice(0, 19);
      const p = n => String(n).padStart(2, '0');
      return `${d.getFullYear()}/${p(d.getMonth() + 1)}/${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
    };
    const elapsed = startedAt => {
      if (!startedAt) return '0 秒';
      const seconds = Math.max(0, Math.floor((Date.now() - Date.parse(startedAt)) / 1000));
      if (seconds < 60) return `${seconds} 秒`;
      return `${Math.floor(seconds / 60)} 分 ${String(seconds % 60).padStart(2, '0')} 秒`;
    };
    const notice = text => { ui.message = text; render(); };

    // ---------------------------------------------------------------- 数据加载
    async function refreshShelf() {
      const [q, logs, resumeTasks, config, report] = await Promise.all([
        api('selectionpool.queueStatus', {}).catch(() => null),
        api('selectionpool.autoShelfLog', {}).catch(() => []),
        api('selectionpool.resumeTasks', {}).catch(() => null),
        api('selectionpool.autoShelfConfig', {}).catch(() => null),
        api('selectionpool.publicationReport', { tab: 'failures', page: 1, size: 6 }).catch(() => null),
      ]);
      if (q) ui.shelf.queue = q;
      ui.shelf.logs = Array.isArray(logs) ? logs.slice(-120) : [];
      if (resumeTasks) ui.shelf.resume = resumeTasks;
      if (config) ui.shelf.config = config;
      if (report) ui.pub.data = report;
      if (!ui.shelf.shops.size) {
        for (const row of loggedIn()) ui.shelf.shops.add(row.storeId);
      }
      render();
    }

    async function refreshPublication() {
      const [report, tasks, shelfRecords] = await Promise.all([
        api('selectionpool.publicationReport', { tab: ui.pub.tab === 'operators' ? 'operators' : 'failures', keyword: ui.pub.keyword, page: ui.pub.page, size: ui.pub.size }).catch(() => null),
        api('selectionpool.resumeTasks', {}).catch(() => null),
        ui.pub.tab === 'records' ? api('selectionpool.shelfRecords', {}).catch(() => []) : Promise.resolve(null),
      ]);
      if (report) ui.pub.data = report;
      if (tasks) ui.pub.resume = tasks;
      if (Array.isArray(shelfRecords)) ui.pub.shelfRecords = shelfRecords;
      if (ui.pub.tab === 'logs') await refreshLogs();
      else render();
    }

    async function loadForm(itemId) {
      const detail = await api('selectionpool.detail', { itemId });
      const attributes = (detail?.attributes || detail?.listing?.attributes || []).map(a => ({ name: String(a.name || ''), value: String(a.value || '') }));
      ui.form = {
        itemId, detail, section: 'basic', attributes,
        categoryId: String(detail?.listing?.categoryId || detail?.categoryId || ''),
        categoryPath: String(detail?.listing?.categoryPath || detail?.categoryPath || ''),
        warehouseItemId: String(detail?.warehouseItemId || ''), message: '',
      };
      render();
    }

    async function loadCategory(itemId) {
      const detail = await api('selectionpool.detail', { itemId }).catch(() => null);
      const list = loggedIn();
      const profileId = ui.cat.profileId || list[0]?.storeId || '';
      ui.cat = {
        ...ui.cat, itemId, profileId, keyword: '', levels: [[], [], []], ids: ['', '', ''],
        picked: null, hits: [], busy: false,
        productId: String(detail?.product?.id || detail?.snapshot?.product_id || detail?.snapshot?.item_id || ''),
        personal: null,
        message: detail?.listing?.categoryPath ? `当前类目：${detail.listing.categoryPath}${detail.listing.categoryId ? ` · ID ${detail.listing.categoryId}` : ''}` : '还没采集到类目',
      };
      render();
      // 个人淘宝号登录状态（读商品真实类目用它——店铺子账号打开商品页会被淘宝要求重新登录）。
      void api('personaltaobao.status', {}).then(s => { ui.cat.personal = Boolean(s?.loggedIn); render(); }).catch(() => undefined);
      if (profileId) await loadLevel(0, '');
    }

    async function loadLevel(level, parentId) {
      ui.cat.busy = true; render();
      try {
        const result = await api('selectionpool.categoryChildren', { parentId, profileId: ui.cat.profileId, refresh: level === 0 && Boolean(ui.cat.message === 'refresh') });
        const levels = ui.cat.levels.slice();
        levels[level] = result?.items || [];
        for (let i = level + 1; i < 3; i++) levels[i] = [];
        const ids = ui.cat.ids.slice();
        for (let i = level; i < 3; i++) ids[i] = '';
        ui.cat.levels = levels;
        ui.cat.ids = ids;
        ui.cat.picked = null;
        if (!result?.ok && result?.message) ui.cat.message = result.message;
      } catch (error) { ui.cat.message = String(error?.message || error); }
      finally { ui.cat.busy = false; render(); }
    }

    async function loadDetail(itemId) {
      // 老软件打开快，很大一部分是「缓存了详情」：这里同样做 stale-while-revalidate，
      // 命中缓存立刻出画面，同时后台刷一次最新数据（用户 2026-11-12：我们打开比老软件慢）。
      const cached = detailCache.get(itemId);
      ui.detail = {
        ...ui.detail, itemId, busy: !cached, error: '', imageIndex: 0,
        data: cached ? cached.data : (ui.detail.itemId === itemId ? ui.detail.data : null),
      };
      if (cached) ui.detail.tab = ui.detail.tab || 'overview';
      render();
      if (cached) {
        void api('selectionpool.detail', { itemId })
          .then(fresh => {
            detailCache.set(itemId, { at: Date.now(), data: fresh });
            if (ui.detail.itemId === itemId && ui.name === 'detail') { ui.detail.data = fresh; render(); }
          })
          .catch(() => undefined);
        return;
      }
      try {
        const fresh = await api('selectionpool.detail', { itemId });
        detailCache.set(itemId, { at: Date.now(), data: fresh });
        ui.detail = { ...ui.detail, itemId, data: fresh, busy: false, error: '' };
      } catch (error) {
        ui.detail = { ...ui.detail, busy: false, error: String(error?.message || error) };
      }
      render();
    }

    function open(name, payload = {}) {
      ui.name = name;
      ui.message = '';
      if (name === 'autoShelf') {
        ui.shelf.itemIds = Array.isArray(payload.itemIds) ? payload.itemIds.slice() : [];
        void refreshShelf();
      } else if (name === 'publication') {
        const nextTab = ['failures', 'records', 'logs', 'operators'].includes(payload.tab) ? payload.tab : 'failures';
        ui.pub.tab = nextTab;
        ui.pub.page = 1;
        ui.pub.keyword = '';
        ui.pub.itemId = Number(payload.itemId) || 0;
        if (nextTab === 'logs') {
          ui.logs = { runs: [], runId: payload.runId || '', busy: true, error: '' };
        }
        void refreshPublication();
      } else if (name === 'manualForm' && payload.itemId) {
        void loadForm(Number(payload.itemId));
      } else if (name === 'category' && payload.itemId) {
        void loadCategory(Number(payload.itemId));
      } else if (name === 'detail' && payload.itemId) {
        ui.detail = { itemId: Number(payload.itemId), tab: payload.tab || 'overview', data: null, busy: true, error: '', imageIndex: 0 };
        void loadDetail(Number(payload.itemId));
      } else if (name === 'logs') {
        ui.name = 'publication';
        ui.pub.tab = 'logs';
        ui.pub.itemId = 0;
        ui.logs = { runs: [], runId: payload.runId || '', busy: true, error: '' };
        void refreshPublication();
      }
      render();
    }

    const close = () => { ui.name = ''; ui.message = ''; render(); };
    const isOpen = () => Boolean(ui.name);

    // ---------------------------------------------------------------- 各弹窗 HTML
    /**
     * 上架进度侧栏（用户 2026-11-21）：自动上架弹窗右侧加宽，
     * 逐件显示正在上架、排队中、成功入仓和失败原因。
     */
    const QUEUE_STATE = {
      queued: { label: '排队中', tone: 'queued' },
      running: { label: '上架中', tone: 'running' },
      done: { label: '成功', tone: 'done' },
      failed: { label: '失败', tone: 'failed' },
      stopped: { label: '未执行', tone: 'failed' },
    };
    const queueTitle = row => row.title || (data().items || []).find(x => Number(x.itemId) === Number(row.itemId))?.title || '正在读取标题…';
    function queueSideStats(q) {
      const items = Array.isArray(q?.items) ? q.items : [];
      const total = Number(q?.total) || items.length;
      const done = Number(q?.done) || 0;
      const ok = Number(q?.ok) || 0;
      const fail = Number(q?.fail) || 0;
      const percent = total ? Math.min(100, Math.round(done / total * 100)) : 0;
      const running = items.find(r => r.status === 'running');
      const current = q?.running
        ? (running ? `正在上架：选品#${running.itemId} ${short(queueTitle(running), 14)}` : '正在准备下一件…')
        : (items.length ? '本次队列已结束' : '点「开始上架」后显示逐件进度');
      return { items, total, done, ok, fail, percent, current };
    }
    function queueSideRow(row, index) {
      const info = QUEUE_STATE[row.status] || QUEUE_STATE.queued;
      const title = queueTitle(row);
      const detail = info.tone === 'running' ? `已用时 ${elapsed(row.startedAt)}`
        : info.tone === 'failed' ? (row.message || row.code || '失败')
        : info.tone === 'done' ? (row.message || '已放入仓库')
        : '等待处理';
      return `<div class="spx-side-row is-${info.tone}" title="选品#${esc(row.itemId)} ${esc(title)} · ${esc(detail)}">
        <span class="spx-side-index">${index + 1}</span>
        <span class="spx-side-name"><b>#${esc(row.itemId)} · ${esc(short(title, 16))}</b><span>${esc(short(detail, 24))}</span></span>
        <span class="spx-side-state">${esc(info.label)}</span>
      </div>`;
    }
    function shelfProgressSide(q) {
      const s = queueSideStats(q);
      return `<aside class="spx-shelf-side" data-spx-side>
        <div class="spx-side-head"><div><b>上架进度</b><span data-spx-side-current>${esc(s.current)}</span></div><em data-spx-side-percent>${s.percent}%</em></div>
        <div class="spx-side-summary" data-spx-side-summary>上架中 ${s.done}/${s.total} · 成功 ${s.ok} · 失败 ${s.fail}</div>
        <div class="spx-bar spx-side-bar"><i data-spx-side-bar style="width:${s.percent}%"></i></div>
        <div class="spx-side-list" data-spx-side-list>${s.items.length ? s.items.map((r, i) => queueSideRow(r, i)).join('') : '<div class="spx-side-empty">还没有执行记录。点「开始上架」后，这里会逐件显示排队中、上架中、成功和失败。</div>'}</div>
      </aside>`;
    }

    function shelfDialog() {
      const q = queue();
      const c = cfg();
      const list = shops();
      const chosen = ui.shelf.shops;
      const ids = ui.shelf.itemIds;
      const lines = (q.lines || []).length ? q.lines : ui.shelf.logs.map(l => l.line || '');
      const tasks = (resume().items || []).slice(0, 4);
      const percent = q.total ? Math.min(100, Math.round((Number(q.done) || 0) / q.total * 100)) : 0;
      return `<div class="spx-backdrop" data-spx="autoShelf"><div class="spx-dialog spx-shelf spx-shelf-wide">
        <div class="spx-head"><div class="spx-head-icon">${svg('arrow')}</div>
          <div class="spx-head-text"><h2>自动上架 / 上传到店铺</h2><span>${ids.length ? `已选 ${ids.length} 件选品` : '队列运行中 · 勾选其他选品后可追加到队列'}</span></div>
          <button type="button" class="spx-x" data-action="selectionpool:dlg-close" title="收起弹窗，队列在后台继续运行">×</button></div>
        <div class="spx-shelf-main">
        <div class="spx-body">
          <section class="spx-sec"><div class="spx-label">选择目标店铺</div>
            <div class="spx-shops">${list.length ? list.map(s => {
              const ok = s.state === 'logged-in' || loggedIn().some(x => x.storeId === s.storeId);
              const on = chosen.has(s.storeId);
              return `<label class="spx-shop ${on ? 'on' : ''} ${ok ? '' : 'off'}"><input type="checkbox" data-action="selectionpool:dlg-shelf-shop" data-id="${esc(s.storeId)}" ${on ? 'checked' : ''} ${ok ? '' : 'disabled'}>
                <i class="spx-shop-logo">${esc(String(s.name || '店').slice(0, 1))}</i><span class="spx-shop-name">${esc(s.name || '未命名店铺')}</span>
                <em class="spx-shop-state ${ok ? 'ok' : 'bad'}">${ok ? '在线' : (s.label || '登录已过期')}</em></label>`;
            }).join('') : '<p class="spx-note">还没有登记店铺，请先到「店铺登录」添加。</p>'}</div></section>

          <section class="spx-sec spx-toggle-sec"><label class="spx-toggle"><input type="checkbox" data-action="selectionpool:dlg-shelf-config" data-key="autoPublish" ${c.autoPublish ? 'checked' : ''}><i></i></label>
            <div class="spx-toggle-text"><b>自动上架</b><span>放入仓库 · 不立即上架</span></div>
            <span class="spx-chip">放进仓库</span></section>

          <section class="spx-sec"><div class="spx-label">店铺分类 <small>选填 · 发布页「店铺中分类」，每家店铺分别选，下次自动带出</small></div>
            ${[...chosen].map(id => {
              const s = list.find(x => x.storeId === id) || { name: id };
              const options = (ui.shelf.shopCats[id] || []);
              const saved = (c.shopCategoryIds || {})[id];
              const selectedId = String(Array.isArray(saved) ? (saved[0] || '') : (saved || ''));
              return `<div class="spx-shopcat-row"><span>${esc(s.name || id)}</span>
                <select class="spx-select" data-action="selectionpool:dlg-shelf-shopcat" data-id="${esc(id)}"><option value="">未设置（上架时自动带出）</option>${options.map(o => `<option value="${esc(o.id)}" ${String(o.id) === selectedId ? 'selected' : ''}>${esc(o.path || o.name)}</option>`).join('')}</select>
                <button type="button" class="button small" data-action="selectionpool:dlg-shelf-shopcat-refresh" data-id="${esc(id)}">刷新</button></div>`;
            }).join('') || '<p class="spx-note">先在上面勾选店铺。</p>'}</section>

          <section class="spx-sec spx-price"><b>上架价格</b><span>同行价 ×</span>
            <input class="spx-input mini" data-action="selectionpool:dlg-shelf-config" data-key="priceFactor" value="${esc(c.priceFactor || '1')}" aria-label="倍数">
            <select class="spx-select mini" data-action="selectionpool:dlg-shelf-config" data-key="priceDirection" aria-label="减或加"><option value="subtract" ${c.priceDirection !== 'add' ? 'selected' : ''}>减</option><option value="add" ${c.priceDirection === 'add' ? 'selected' : ''}>加</option></select>
            <input class="spx-input mini" data-action="selectionpool:dlg-shelf-config" data-key="priceOffset" value="${esc(c.priceOffset || '1')}" aria-label="金额"><span>元</span>
            <em class="spx-price-eg">例：同行价 10 元 → 9 元 · 不改价</em></section>
          <p class="spx-price-note">对这次上架的全部选品、全部规格生效，倍数和金额都支持两位小数。在商品工作台里单独改过价格的规格按工作台保存的价格，不再套这条规则。</p>

          <div class="spx-info">${svg('info')}<span>${esc(TIPS)}</span></div>

<section class="spx-progress"><div class="spx-progress-line"><span data-spx-progress>上架中 ${Number(q.done) || 0}/${Number(q.total) || 0} · 成功 ${Number(q.ok) || 0} · 失败 ${Number(q.fail) || 0}</span><span>${percent}%</span></div>
            <div class="spx-bar"><i style="width:${percent}%"></i></div>
            <div class="spx-log-head"><b>完整日志</b><span>${lines.length} 行</span>
              <button type="button" class="link-button" data-action="selectionpool:dlg-shelf-log-copy">复制全部</button>
              <button type="button" class="link-button" data-action="selectionpool:dlg-shelf-log-more">${ui.shelf.logAll ? '只看最近 80 行' : '看全部'}</button></div>
            <div class="spx-log" data-spx-log="1">${lines.length ? [...lines].slice(ui.shelf.logAll ? -600 : -80).map(l => `<div>${esc(l)}</div>`).join('') : '<div class="dim">还没有执行日志。点「开始上架」后会逐行显示。</div>'}</div>
          </section>

          ${tasks.length ? `<section class="spx-resume"><div class="spx-resume-head"><b>没入仓、可以接着处理的任务</b><span>${esc(resume().note || '')}</span></div>
            ${tasks.map(r => `<div class="spx-resume-row"><div class="spx-resume-text"><strong>选品#${esc(r.itemId)} → ${esc(short(r.title || '未命名商品', 24))}</strong><span>${esc(short(r.reason || '参数或类目不全', 90))}</span></div>
              <div class="spx-resume-acts"><button type="button" class="button small" data-action="selectionpool:dlg-resume-open-shop" data-id="${esc(r.itemId)}">打开店铺窗口</button>
              <button type="button" class="button primary small" data-action="selectionpool:dlg-resume-continue" data-id="${esc(r.itemId)}">继续入仓</button></div></div>`).join('')}
            <p class="spx-resume-tail">${esc(resume().tail || '')}</p></section>` : ''}
        </div>
        ${shelfProgressSide(q)}
        </div>
        <div class="spx-foot"><span class="spx-hint">点「后台运行」收起弹窗，队列继续跑；运行中可追加其他选品。</span>
          <button type="button" class="button small" data-action="selectionpool:dlg-shelf-stop" ${q.running ? '' : 'disabled'}>停止队列</button>
          <button type="button" class="button small" data-action="selectionpool:dlg-close">后台运行</button>
          <button type="button" class="button primary small" data-action="selectionpool:dlg-shelf-start" ${ui.busy ? 'disabled' : ''}>${q.running ? (ids.length ? '追加到队列' : '上架中…') : '开始上架'}</button></div>
      </div></div>`;
    }

    function publicationRecordsTab() {
      const kw = String(ui.pub.keyword || '').trim().toLowerCase();
      const filterItemId = Number(ui.pub.itemId) || 0;
      const all = [...(ui.pub.shelfRecords || [])].reverse();
      const filtered = all.filter(r => {
        if (filterItemId && Number(r.itemId) !== filterItemId) return false;
        if (!kw) return true;
        return [r.itemId, r.shopName, r.warehouseItemId, r.status, r.title].some(v => String(v || '').toLowerCase().includes(kw));
      });
      const filterBar = `<div class="spx-search">
        <input class="spx-input" data-dlg-pub-keyword value="${esc(ui.pub.keyword)}" placeholder="选品 ID / 店铺名 / 仓库商品编号" aria-label="搜索入仓记录">
        <button type="button" class="button primary small" data-action="selectionpool:dlg-pub-query">查询</button>
        <button type="button" class="button small" data-action="selectionpool:dlg-pub-refresh">刷新</button>
        ${filterItemId ? `<button type="button" class="button small" data-action="selectionpool:dlg-pub-clear-item">仅看选品 #${filterItemId} · 显示全部</button>` : ''}
      </div>`;
      if (!filtered.length) return `${filterBar}<p class="spx-note spx-empty">${filterItemId ? `选品 #${filterItemId} 还没有成功入仓记录。` : '暂无入仓记录。自动上架成功后会记录目标店铺与仓库商品编号。'}</p>`;
      return `${filterBar}<div class="spx-records-table">
        <div class="spx-records-tr spx-records-th"><span>时间</span><span>选品</span><span>目标店铺</span><span>仓库商品编号</span><span>状态</span></div>
        ${filtered.slice(0, 100).map(r => `<div class="spx-records-tr">
          <span class="mono">${esc(time(r.at))}</span>
          <span class="mono">#${esc(r.itemId)}</span>
          <span class="clip">${esc(r.shopName || '—')}</span>
          <span class="mono">${esc(r.warehouseItemId || '—')}</span>
          <span><em class="spx-fixed">${esc(r.status || '已入仓')}</em></span>
        </div>`).join('')}
      </div>`;
    }

    function publicationLogsTab() {
      const st = ui.logs || { runs: [], runId: '' };
      const current = st.runId ? (st.runs || []).find(r => r.runId === st.runId) : null;
      if (current) {
        const lines = (current.lines || []).map(row => row.line).filter(Boolean);
        return `<div class="spx-log-subbar">
          <span class="spx-hint">选品 ${esc(current.items?.length ? `#${current.items.join('、#')}` : current.runId)} · ${esc(time(current.startedAt))} → ${esc(time(current.finishedAt))} · 成功 ${current.ok} · 失败 ${current.fail}</span>
          <button type="button" class="button small" data-action="selectionpool:dlg-log-back">返回列表</button>
          <button type="button" class="button small" data-action="selectionpool:dlg-log-copy">复制全部</button>
        </div>
        <div class="spx-log" data-spx-log="1">${lines.length ? lines.map(l => `<div>${esc(l)}</div>`).join('') : '<div class="dim">这次上架没有日志行</div>'}</div>`;
      }
      const rows = st.runs || [];
      return `<div class="spx-log-subbar">
        <span class="spx-hint">每次执行一行，点击「查看」可展开该次完整步骤与回执日志。</span>
        <button type="button" class="button small" data-action="selectionpool:dlg-log-refresh">刷新</button>
      </div>
      ${st.error ? `<p class="spx-note spx-error">${esc(st.error)}</p>` : ''}
      ${st.busy ? '<p class="spx-note">正在读取执行日志…</p>' : ''}
      ${rows.length ? `<div class="spx-run-table">
        <div class="spx-run-tr spx-run-th"><span>时间</span><span>选品</span><span>结果</span><span>行数</span><span>操作</span></div>
        ${rows.map(run => `<div class="spx-run-tr">
          <span class="mono">${esc(time(run.finishedAt || run.startedAt))}</span>
          <span class="clip">${esc((run.items || []).map(id => `#${id}`).join('、') || '—')}</span>
          <span>${run.ok ? `<em class="ok">成功 ${run.ok}</em>` : ''}${run.fail ? `<em class="bad">失败 ${run.fail}</em>` : ''}${!run.ok && !run.fail ? '—' : ''}</span>
          <span>${esc(String(run.lineCount || 0))}</span>
          <span><button type="button" class="link-button" data-action="selectionpool:dlg-log-open" data-run="${esc(run.runId)}">查看</button></span>
        </div>`).join('')}</div>`
        : (st.busy ? '' : '<p class="spx-note spx-empty">还没有执行日志。上架一次后这里会记录每一次完整过程。</p>')}`;
    }

    function publicationDialog() {
      const p = pub();
      const rows = p.rows || [];
      const totals = p.totals || { success: 0, failed: 0 };
      const tasks = (ui.pub.resume?.items || resume().items || []).slice(0, 3);
      const tab = ui.pub.tab;
      return `<div class="spx-backdrop" data-spx="publication"><div class="spx-dialog spx-pub">
        <div class="spx-head"><div class="spx-head-text"><h2>上品记录中心</h2><span>累计成功 ${totals.success} 次 · 失败 ${totals.failed} 次 · 尝试 ${totals.attempts || (totals.success + totals.failed)} 次</span></div>
          <button type="button" class="spx-x" data-action="selectionpool:dlg-close" title="关闭">×</button></div>
        <div class="spx-tabs">
          <button type="button" class="${tab === 'failures' ? 'on' : ''}" data-action="selectionpool:dlg-pub-tab" data-value="failures">失败排查${totals.failed ? ` (${totals.failed})` : ''}</button>
          <button type="button" class="${tab === 'records' ? 'on' : ''}" data-action="selectionpool:dlg-pub-tab" data-value="records">成功入仓</button>
          <button type="button" class="${tab === 'logs' ? 'on' : ''}" data-action="selectionpool:dlg-pub-tab" data-value="logs">执行日志</button>
          <button type="button" class="${tab === 'operators' ? 'on' : ''}" data-action="selectionpool:dlg-pub-tab" data-value="operators">统计与员工</button>
        </div>
        <div class="spx-body spx-pub-body">
          ${tab === 'records' ? publicationRecordsTab() : ''}
          ${tab === 'logs' ? publicationLogsTab() : ''}
          ${tab === 'operators' ? (() => {
            const opRows = Array.isArray(p.byOperator) ? p.byOperator : [];
            return `<div class="spx-overview"><div><span>累计上品成功</span><b>${totals.success}</b></div><div><span>失败</span><b>${totals.failed}</b></div><div><span>上品尝试</span><b>${totals.attempts || (totals.success + totals.failed)}</b></div></div>
            <p class="spx-note">每次上架尝试单独计数，失败后重试成功会保留原失败记录；停止、等待登录和未执行商品不计数。</p>
            ${opRows.length ? `<div class="spx-operator-table"><div class="spx-operator-tr spx-operator-th"><span>员工</span><span>尝试</span><span>成功</span><span>失败</span><span>成功率</span><span>主要失败原因</span></div>
              ${opRows.map(row => `<div class="spx-operator-tr"><span>${esc(row.operatorName || '本机')}${row.teamName ? `<em class="spx-op-team">${esc(row.teamName)}</em>` : ''}</span><span>${row.attempts}</span><span class="ok">${row.success}</span><span class="${row.failed ? 'bad' : ''}">${row.failed}</span><span class="spx-op-rate ${row.rate >= 80 ? 'ok' : row.rate >= 50 ? 'warn' : 'bad'}">${row.rate}%</span><span class="clip">${esc((row.topReasons || []).map(r => `${r.code}×${r.count}`).join(' · ') || '—')}</span></div>`).join('')}</div>`
              : '<p class="spx-note">还没有上架记录。上架一次后这里会按员工统计成功率。</p>'}`;
          })() : ''}
          ${tab === 'failures' ? `<div class="spx-search"><input class="spx-input" data-dlg-pub-keyword value="${esc(ui.pub.keyword)}" placeholder="商品 ID / 店铺 / 失败原因 / 员工" aria-label="搜索失败记录">
            <button type="button" class="button primary small" data-action="selectionpool:dlg-pub-query">查询</button>
            <button type="button" class="button small" data-action="selectionpool:dlg-pub-refresh">刷新</button></div>
            ${rows.length ? rows.map(r => `<div class="spx-fail-card">
            <div class="spx-fail-top"><strong>${esc(short(r.title || '未命名商品', 60))}</strong>
              ${r.fixedIn ? `<em class="spx-fixed">已修复 · ${esc(r.fixedIn)}</em>` : ''}<span class="spx-fail-time">${esc(time(r.at))}</span></div>
            <div class="spx-fail-meta">商品 ID: ${esc(r.productId || '—')} · 选品 #${esc(r.itemId || '—')}${r.operatorName ? ` · ${esc(r.operatorName)}` : ''} · ${esc(r.shopName || '—')}</div>
            <div class="spx-fail-reason">${esc(r.code || 'PUBLISH_FAILED')} · ${esc(r.summary || r.message || '失败')}</div>
            ${ui.pub.expanded === r.id ? `<pre class="spx-fail-full">${esc(r.diagnostic || rowMessage(r))}</pre>` : ''}
            <div class="spx-fail-acts"><button type="button" class="button small" data-action="selectionpool:dlg-pub-expand" data-id="${esc(r.id)}">${ui.pub.expanded === r.id ? '收起原因' : '完整原因'}</button>
              <button type="button" class="button small" data-action="selectionpool:dlg-pub-copy" data-id="${esc(r.id)}">复制排查信息</button>
              <button type="button" class="button small" data-action="selectionpool:dlg-pub-open-form" data-id="${esc(r.itemId)}">填写补全结果</button>
              <button type="button" class="button small" data-action="selectionpool:dlg-pub-open-shop" data-id="${esc(r.itemId)}">打开店铺窗口</button>
              <button type="button" class="button primary small" data-action="selectionpool:dlg-pub-resume" data-id="${esc(r.itemId)}">继续入仓</button></div>
          </div>`).join('') : '<p class="spx-note spx-empty">这段时间没有失败记录。</p>'}` : ''}
          ${tab === 'failures' && tasks.length ? `<section class="spx-resume"><div class="spx-resume-head"><b>没入仓、可以接着处理的任务</b><span>也可以在这里手动打开店铺窗口处理。</span></div>
            ${tasks.map(r => `<div class="spx-resume-row"><div class="spx-resume-text"><strong>选品#${esc(r.itemId)} → ${esc(short(r.title || '', 24))}</strong><span>${esc(short(r.reason || '', 80))}</span></div>
              <div class="spx-resume-acts"><button type="button" class="button small" data-action="selectionpool:dlg-resume-open-shop" data-id="${esc(r.itemId)}">打开店铺窗口</button>
              <button type="button" class="button primary small" data-action="selectionpool:dlg-resume-continue" data-id="${esc(r.itemId)}">继续入仓</button></div></div>`).join('')}</section>` : ''}
        </div>
        <div class="spx-foot">${tab === 'failures' ? `<span class="spx-hint">共 ${p.total || 0} 条失败记录</span>
          <button type="button" class="button small" data-action="selectionpool:dlg-pub-page" data-value="${Math.max(1, (p.page || 1) - 1)}" ${(p.page || 1) <= 1 ? 'disabled' : ''}>上一页</button>
          <span>${p.page || 1}/${p.pages || 1}</span>
          <button type="button" class="button small" data-action="selectionpool:dlg-pub-page" data-value="${(p.page || 1) + 1}" ${(p.page || 1) >= (p.pages || 1) ? 'disabled' : ''}>下一页</button>`
          : `<span class="spx-hint">${tab === 'records' ? `共 ${(ui.pub.shelfRecords || []).length} 条入仓记录` : tab === 'logs' ? `共 ${(ui.logs.runs || []).length} 次执行记录` : '含成功/失败与员工统计'}</span>`}
          <button type="button" class="button small" data-action="selectionpool:dlg-close">关闭</button></div>
      </div></div>`;
    }
    const rowMessage = r => r?.message || '';

    function formDialog() {
      const f = ui.form;
      const attrs = f.attributes || [];
      const d = f.detail || {};
      const section = FORM_SECTIONS.find(s => s.id === f.section) || FORM_SECTIONS[0];
      return `<div class="spx-backdrop" data-spx="manualForm"><div class="spx-dialog spx-form">
        <div class="spx-form-tabs"><span class="on">编辑中</span><span>基线信息</span><span>其他信息</span><span>销售信息</span><span>指定类目及属性</span>
          <button type="button" class="spx-x" data-action="selectionpool:dlg-close" title="关闭">×</button></div>
        <div class="spx-form-main">
          <aside class="spx-form-nav"><div class="spx-form-nav-head">选品#${esc(f.itemId)} · ${esc(short(d?.product?.title || '商品信息', 16))}</div>
            ${FORM_SECTIONS.map(s => `<button type="button" class="${s.id === f.section ? 'on' : ''}" data-action="selectionpool:dlg-form-section" data-value="${esc(s.id)}">${esc(s.label)}${s.required ? '<i>*</i>' : ''}</button>`).join('')}</aside>
          <div class="spx-form-fields">
            <div class="spx-form-sec-h"><h3>${esc(section.label)}</h3><span>${f.message ? esc(f.message) : '在这里补全店铺发布页需要的字段，保存后会写回这条选品。'}</span></div>
            <div class="spx-form-grid">
              <label><span>类目 ID</span><input class="spx-input" data-dlg-form="categoryId" value="${esc(f.categoryId)}" placeholder="叶子类目 ID"></label>
              <label><span>类目路径</span><input class="spx-input" data-dlg-form="categoryPath" value="${esc(f.categoryPath)}" placeholder="一级 / 二级 / 叶子类目"></label>
            </div>
            <div class="spx-form-row">
              <button type="button" class="button small" data-action="selectionpool:dlg-form-read-category">采集原链接类目</button>
              <button type="button" class="button small" data-action="selectionpool:dlg-form-category">选择类目</button>
              <button type="button" class="button small" data-action="selectionpool:dlg-form-open-shop">打开店铺窗口</button></div>
            <div class="spx-form-sec-h"><h3>商品参数 <em>${attrs.length}</em></h3><span>改过的项上架时照抄填写</span></div>
            ${attrs.length ? `<div class="spx-form-attrs">${attrs.map((a, i) => `<label><span title="${esc(a.name)}">${esc(a.name)}</span><input class="spx-input" data-dlg-form-attr="${i}" value="${esc(a.value)}"></label>`).join('')}</div>` : '<p class="spx-note">还没有采集到参数，可在下面新增。</p>'}
            <div class="spx-form-row"><input class="spx-input" data-dlg-form-new-name placeholder="参数名，例如 厂址"><input class="spx-input" data-dlg-form-new-value placeholder="参数值">
              <button type="button" class="button small" data-action="selectionpool:dlg-form-add-attr">增加参数</button></div>
            <div class="spx-form-grid"><label><span>仓库商品编号（已在店铺页面入仓时填）</span><input class="spx-input" data-dlg-form="warehouseItemId" value="${esc(f.warehouseItemId)}"></label></div>
          </div>
          <aside class="spx-form-preview"><div class="spx-phone"><div class="spx-phone-head">手机预览</div>
            <div class="spx-phone-img">${/^https:\/\//.test(d?.product?.imageUrl || '') ? `<img src="${esc(d.product.imageUrl)}" alt="">` : '<span>商品主图</span>'}</div>
            <div class="spx-phone-title">${esc(short(d?.product?.title || '商品标题', 28))}</div>
            <div class="spx-phone-price">¥ ${esc(d?.product?.priceLabel || '—')}</div>
            <div class="spx-phone-note">这里显示商品信息预览，真实发布页在店铺窗口里填写。</div></div></aside>
        </div>
        <div class="spx-foot"><span class="spx-hint">保存后可在「上品记录」里点「继续入仓」，不会自动提交。</span>
          <button type="button" class="button small" data-action="selectionpool:dlg-close">取消</button>
          <button type="button" class="button small" data-action="selectionpool:dlg-form-open-shop">打开店铺窗口</button>
          <button type="button" class="button small" data-action="selectionpool:dlg-form-save">保存补全结果</button>
          <button type="button" class="button primary small" data-action="selectionpool:dlg-form-resume">我已改好，继续</button></div>
      </div></div>`;
    }

    /* ---------------------------------------------------------------- 采集信息（详情） */
    const notTaken = '<em class="spx-miss">未采集</em>';
    const yuan = fen => (fen == null || !Number.isFinite(Number(fen)) ? '' : (Number(fen) / 100).toFixed(2));
    /**
     * 缩略图地址：alicdn 支持 `_120x120.jpg` 后缀返回小图，列表/缩略图用它，
     * 详情页一次要加载十几张图，用原图会明显变慢（用户 2026-11-12：老软件打开快、我们慢）。
     */
    const thumbUrl = (url, size = 120) => {
      const raw = String(url || '');
      if (!/^https:\/\//i.test(raw)) return raw;
      if (!/(?:alicdn|aliimg)\.com/i.test(raw)) return raw;
      if (/_\d+x\d+\.(?:jpe?g|png|webp)$/i.test(raw)) return raw;
      if (!/\.(?:jpe?g|png|webp)$/i.test(raw)) return raw;
      return `${raw}_${size}x${size}.jpg`;
    };

    function detailRows(d) {
      const p = d.product || {};
      const price = d.price || {};
      const shop = d.shop || {};
      return [
        ['店铺', p.shopName || shop.name || ''],
        ['采集价', p.priceFen != null ? `¥${yuan(p.priceFen)}` : (p.priceLabel || '')],
        ['原价', price.originalFen != null ? `¥${yuan(price.originalFen)}` : ''],
        ['促销价', price.promotionFen != null ? `¥${yuan(price.promotionFen)}` : ''],
        ['品牌', d.brand || ''],
        ['类目路径', d.categoryPath || ''],
        ['类目ID', d.categoryId || ''],
        ['采集时间', p.collectedAt ? time(p.collectedAt) : ''],
        ['副标题', d.subtitle || ''],
        ['服务承诺', (d.services || []).join(' · ')],
      ];
    }

    function detailCard(title, body) {
      return `<section class="spx-info-card"><div class="spx-info-card-h">${esc(title)}</div><div class="spx-info-card-b">${body || `<p class="spx-note">${notTaken}</p>`}</div></section>`;
    }

    function detailOverview(d) {
      const p = d.product || {};
      const images = (d.images || []).filter(u => /^https:\/\//i.test(u));
      const index = Math.min(ui.detail.imageIndex || 0, Math.max(0, images.length - 1));
      const main = images[index] || (p.imageUrl && /^https:\/\//i.test(p.imageUrl) ? p.imageUrl : '');
      const shop = d.shop || {};
      const ship = d.shipping || {};
      const sales = d.sales || {};
      return `<div class="spx-info-main">
        <div class="spx-info-media">
          <div class="spx-info-hero">${main ? `<img src="${esc(main)}" alt="">` : `<span>${notTaken}</span>`}</div>
          ${images.length ? `<div class="spx-info-thumbs">${images.slice(0, 8).map((u, i) => `<button type="button" class="${i === index ? 'on' : ''}" data-action="selectionpool:dlg-detail-image" data-index="${i}"><img src="${esc(thumbUrl(u, 80))}" alt="" loading="lazy" decoding="async" referrerpolicy="no-referrer"></button>`).join('')}</div>` : ''}
        </div>
        <div class="spx-info-grid">${detailRows(d).map(([label, value]) => `<div class="spx-info-row"><span>${esc(label)}</span><b class="${value ? '' : 'empty'}">${value ? esc(value) : notTaken}</b></div>`).join('')}</div>
      </div>
      <div class="spx-info-cards">
        ${detailCard('销量与评价', sales && Object.keys(sales).length
          ? Object.entries(sales).map(([k, v]) => `<div class="spx-info-row"><span>${esc(k)}</span><b>${esc(String(v))}</b></div>`).join('')
          : '')}
        ${detailCard('店铺信息', Object.keys(shop).length
          ? `<div class="spx-info-row"><span>店铺名</span><b>${esc(shop.name || p.shopName || '—')}</b></div>
             ${shop.sellerId ? `<div class="spx-info-row"><span>卖家 ID</span><b class="mono">${esc(shop.sellerId)}</b></div>` : ''}
             ${shop.url ? `<div class="spx-info-row"><span>店铺链接</span><b class="mono clip">${esc(shop.url)}</b></div>` : ''}
             ${(shop.scores || []).map(s => `<div class="spx-info-row"><span>${esc(s.name)}</span><b>${esc(s.value)}</b></div>`).join('')}`
          : '')}
        ${detailCard('物流', Object.keys(ship).length
          ? Object.entries(ship).filter(([, v]) => v).map(([k, v]) => `<div class="spx-info-row"><span>${esc(k)}</span><b>${esc(String(v))}</b></div>`).join('')
          : '')}
        ${detailCard('主图视频', (d.videos || []).length
          ? (d.videos || []).map((u, i) => `<div class="spx-info-video"><video src="${esc(u)}" ${d.videoPoster ? `poster="${esc(d.videoPoster)}"` : ''} preload="metadata" controls muted></video><button type="button" class="link-button" data-action="selectionpool:dlg-detail-video" data-index="${i}">用系统播放器打开</button></div>`).join('')
          : '')}
      </div>`;
    }

    function detailSku(d) {
      const rows = (d.skus || []);
      if (!rows.length) return `<p class="spx-note">这条选品没有采集到规格。${notTaken}</p>`;
      return `<div class="spx-detail-table"><div class="spx-detail-tr spx-detail-th"><span>SKU</span><span>规格</span><span>价格</span><span>库存</span><span>规格图</span></div>
        ${rows.map(r => {
          // buildDetailView 的字段名是 specs（不是 properties）：之前取错字段导致「规格」列只显示 SKU ID
          const props = Array.isArray(r.specs) ? r.specs : (Array.isArray(r.properties) ? r.properties : []);
          const name = props.map(x => x.value || x.vname || '').filter(Boolean).join(' / ');
          const price = r.priceFen != null ? `¥${yuan(r.priceFen)}` : (r.promotionFen != null ? `¥${yuan(r.promotionFen)}` : '');
          return `<div class="spx-detail-tr">
            <span class="mono clip" title="${esc(r.id || '')}">${esc(r.id || '—')}</span>
            <span class="clip" title="${esc(name || '')}">${name ? esc(name) : notTaken}</span>
            <span>${price ? esc(price) : notTaken}</span>
            <span>${esc(r.stockText || r.availability || '—')}</span>
            <span>${/^https:\/\//i.test(r.imageUrl || '') ? `<img class="spx-detail-skuimg" src="${esc(thumbUrl(r.imageUrl, 80))}" alt="" loading="lazy" decoding="async" referrerpolicy="no-referrer">` : notTaken}</span>
          </div>`;
        }).join('')}</div>`;
    }

    function detailParams(d) {
      const rows = d.attributes || [];
      if (!rows.length) return `<p class="spx-note">没有采集到商品参数。${notTaken}</p>`;
      return `<div class="spx-detail-params">${rows.map(a => `<div class="spx-info-row"><span title="${esc(a.name)}">${esc(a.name)}</span><b>${esc(a.value || '')}</b></div>`).join('')}</div>`;
    }

    function detailDesc(d) {
      const desc = d.description || {};
      const images = (desc.images || []).filter(u => /^https:\/\//i.test(u));
      return `${desc.text ? `<pre class="spx-detail-text">${esc(desc.text)}</pre>` : ''}
        ${images.length ? `<div class="spx-detail-desc">${images.map((u, i) => `<button type="button" class="spx-detail-descimg" data-action="selectionpool:dlg-detail-open" data-url="${esc(u)}"><img src="${esc(thumbUrl(u, 220))}" alt="" loading="lazy" decoding="async" referrerpolicy="no-referrer"><em>${i + 1}</em></button>`).join('')}</div>`
          : `<p class="spx-note">没有采集到图文详情。${notTaken}</p>`}`;
    }

    function detailReviews(d) {
      const rows = d.reviews || [];
      if (!rows.length) return `<p class="spx-note">没有采集到评价（采集时只取页面已渲染的评价，不滚动、不翻页）。${notTaken}</p>`;
      return `<div class="spx-detail-reviews">${rows.map(r => `<div class="spx-review"><p>${esc(r.content || '')}</p>${(r.images || []).length ? `<div class="spx-review-imgs">${r.images.slice(0, 6).map(u => /^https:\/\//i.test(u) ? `<img src="${esc(u)}" alt="">` : '').join('')}</div>` : ''}</div>`).join('')}</div>`;
    }

    function detailSource(d) {
      const source = d.source || {};
      const history = d.history || [];
      return `<div class="spx-detail-params">
        <div class="spx-info-row"><span>商品链接</span><b class="mono clip">${esc(d.product?.productUrl || '—')}</b></div>
        <div class="spx-info-row"><span>归属</span><b>${esc(d.ownerName || '—')}${d.teamName ? ` · ${esc(d.teamName)}` : ''}</b></div>
        <div class="spx-info-row"><span>加入时间</span><b>${esc(time(d.addedAt))}</b></div>
        <div class="spx-info-row"><span>分组 / 标签</span><b>${esc([d.organization?.group, ...(d.organization?.tags || [])].filter(Boolean).join(' · ') || '—')}</b></div>
        ${Object.entries(source).map(([k, v]) => `<div class="spx-info-row"><span>${esc(k)}</span><b>${esc(String(v || ''))}</b></div>`).join('')}
        <div class="spx-info-row"><span>历次采集</span><b>${history.length ? `${history.length} 次 · 最近 ${esc(time(history[history.length - 1]?.receivedAt || history[history.length - 1]?.collectedAt))}` : '—'}</b></div>
        <div class="spx-info-row"><span>图位素材</span><b>1:1 ${(d.images || []).length} · 3:4 ${(d.tallImages || []).length} · SKU ${(d.skuImages || []).length} · 详情 ${(d.description?.images || []).length} · 视频 ${(d.videos || []).length}</b></div>
      </div>`;
    }

    function detailDialog() {
      const st = ui.detail;
      const d = st.data || {};
      const p = d.product || {};
      const tabs = [
        ['overview', '概览', null],
        ['sku', 'SKU', (d.skus || []).length],
        ['params', '商品参数', (d.attributes || []).length],
        ['desc', '图文详情', (d.description?.images || []).length],
        ['reviews', '评价', (d.reviews || []).length],
        ['source', '采集信息', null],
      ];
      const body = st.error ? `<p class="spx-note spx-error">${esc(st.error)}</p>`
        : !st.data ? '<p class="spx-note">正在读取采集信息…</p>'
          : st.tab === 'sku' ? detailSku(d)
            : st.tab === 'params' ? detailParams(d)
              : st.tab === 'desc' ? detailDesc(d)
                : st.tab === 'reviews' ? detailReviews(d)
                  : st.tab === 'source' ? detailSource(d)
                    : detailOverview(d);
      return `<div class="spx-backdrop" data-spx="detail"><div class="spx-dialog spx-detail">
        <div class="spx-head"><div class="spx-head-text">
          <h2>${esc(short(p.title || '未命名商品', 70))}</h2>
          <span>${esc(p.platform === 'tmall' ? '天猫' : p.platform === 'taobao' ? '淘宝' : (p.platform || '—'))} · 商品 ID ${esc(p.id || '—')} · 归属 ${esc(d.ownerName || '—')} · 加入 ${esc(time(d.addedAt))}</span>
        </div>
          ${/^https:\/\//i.test(p.productUrl || '') ? `<button type="button" class="button small" data-action="selectionpool:dlg-detail-open" data-url="${esc(p.productUrl)}">打开原页面</button>` : ''}
          <button type="button" class="button small" data-action="selectionpool:dlg-detail-editor" data-id="${esc(st.itemId)}">商品图片工作台</button>
          <button type="button" class="spx-x" data-action="selectionpool:dlg-close" title="关闭">×</button></div>
        <div class="spx-tabs">${tabs.map(([id, label, count]) => `<button type="button" class="${st.tab === id ? 'on' : ''}" data-action="selectionpool:dlg-detail-tab" data-value="${id}">${esc(label)}${count != null ? `<em>${count}</em>` : ''}</button>`).join('')}</div>
        <div class="spx-body spx-detail-body">${body}</div>
        <div class="spx-foot"><span class="spx-hint">缺失项显示「未采集」，不会编造数值；采集信息页可查看网站保留的历次入库记录。</span>
          <button type="button" class="button small" data-action="selectionpool:dlg-detail-refresh" data-id="${esc(st.itemId)}">重新读取</button>
          <button type="button" class="button small" data-action="selectionpool:dlg-close">关闭</button></div>
      </div></div>`;
    }

    async function refreshLogs() {
      ui.logs = { ...ui.logs, busy: true, error: '' };
      render();
      try {
        const runs = await api('selectionpool.autoShelfRuns', {}).catch(() => []);
        ui.logs = { ...ui.logs, runs: Array.isArray(runs) ? runs : [], busy: false };
      } catch (error) {
        ui.logs = { ...ui.logs, busy: false, error: String(error?.message || error) };
      }
      render();
    }

    /**
     * 上架日志：先列「每一次上架」（时间 / 选品 / 结果 / 行数），点「查看」展开那一次的完整日志。
     * 用户 2026-11-12：现在点开只有一个大窗口，看不到每条商品对应的那一次。
     */
    function logsDialog() {
      const st = ui.logs || { runs: [], runId: '' };
      const current = st.runId ? (st.runs || []).find(r => r.runId === st.runId) : null;
      const fmt = v => time(v);
      if (current) {
        const lines = (current.lines || []).map(row => row.line).filter(Boolean);
        return `<div class="spx-backdrop" data-spx="logs"><div class="spx-dialog spx-logs">
          <div class="spx-head"><div class="spx-head-text"><h2>上架日志 · ${esc(current.items?.length ? `选品#${current.items.join('、#')}` : current.runId)}</h2>
            <span>${esc(fmt(current.startedAt))} → ${esc(fmt(current.finishedAt))} · 成功 ${current.ok} · 失败 ${current.fail} · ${lines.length} 行</span></div>
            <button type="button" class="button small" data-action="selectionpool:dlg-log-back">返回列表</button>
            <button type="button" class="button small" data-action="selectionpool:dlg-log-copy">复制全部</button>
            <button type="button" class="spx-x" data-action="selectionpool:dlg-close" title="关闭">×</button></div>
          <div class="spx-body" style="padding:10px 14px"><div class="spx-log" data-spx-log="1">${lines.length ? lines.map(l => `<div>${esc(l)}</div>`).join('') : '<div class="dim">这次上架没有日志行</div>'}</div></div>
        </div></div>`;
      }
      const rows = st.runs || [];
      return `<div class="spx-backdrop" data-spx="logs"><div class="spx-dialog spx-logs">
        <div class="spx-head"><div class="spx-head-text"><h2>上架日志</h2><span>每次上架一行，点「查看」看那一次的完整日志</span></div>
          <button type="button" class="button small" data-action="selectionpool:dlg-log-refresh">刷新</button>
          <button type="button" class="spx-x" data-action="selectionpool:dlg-close" title="关闭">×</button></div>
        <div class="spx-body" style="padding:10px 14px">
          ${st.error ? `<p class="spx-note spx-error">${esc(st.error)}</p>` : ''}
          ${st.busy ? '<p class="spx-note">正在读取…</p>' : ''}
          ${rows.length ? `<div class="spx-run-table">
            <div class="spx-run-tr spx-run-th"><span>时间</span><span>选品</span><span>结果</span><span>行数</span><span>操作</span></div>
            ${rows.map(run => `<div class="spx-run-tr">
              <span class="mono">${esc(fmt(run.finishedAt || run.startedAt))}</span>
              <span class="clip">${esc((run.items || []).map(id => `#${id}`).join('、') || '—')}</span>
              <span>${run.ok ? `<em class="ok">成功 ${run.ok}</em>` : ''}${run.fail ? `<em class="bad">失败 ${run.fail}</em>` : ''}${!run.ok && !run.fail ? '—' : ''}</span>
              <span>${esc(String(run.lineCount || 0))}</span>
              <span><button type="button" class="link-button" data-action="selectionpool:dlg-log-open" data-run="${esc(run.runId)}">查看</button></span>
            </div>`).join('')}</div>`
            : (st.busy ? '' : '<p class="spx-note">还没有上架记录。上架一次后这里会出现每一次的完整日志。</p>')}
        </div>
        <div class="spx-foot"><span class="spx-hint">日志包含每一步命中/未命中、提交回执；复制后可直接发我定位。</span></div>
      </div></div>`;
    }


    function categoryDialog() {
      const c = ui.cat;
      const picked = c.picked;
      return `<div class="spx-backdrop" data-spx="category"><div class="spx-dialog spx-cat">
        <div class="spx-head"><div class="spx-head-text"><h2>类目</h2><span>${esc(c.message || '')}</span></div>
          <button type="button" class="spx-x" data-action="selectionpool:dlg-close" title="关闭">×</button></div>
        <div class="spx-body">
          <div class="spx-cat-bar"><span class="spx-label">类目</span>
            <span class="spx-cat-current">${esc(picked?.path || '未选择')}${picked ? ` <em>ID ${esc(picked.id)}</em>` : ''} <em>采集</em></span>
            <button type="button" class="button small" data-action="selectionpool:dlg-cat-read" title="插件采集没带类目时按商品 ID 兜底重读（需要本机个人淘宝号会话）">按商品 ID 采集</button></div>
          <div class="spx-cat-tools"><input class="spx-input" data-dlg-cat-keyword value="${esc(c.keyword)}" placeholder="按类目名搜索叶子类目，例如：辣椒酱、果冻" aria-label="搜索类目">
            <button type="button" class="button primary small" data-action="selectionpool:dlg-cat-query">查询</button>
            <label class="spx-cat-source"><span>类目来源</span><select class="spx-select" data-action="selectionpool:dlg-cat-source">${loggedIn().map(s => `<option value="${esc(s.storeId)}" ${c.profileId === s.storeId ? 'selected' : ''}>${esc(s.name)}</option>`).join('') || '<option value="">未登录店铺</option>'}</select></label>
            <button type="button" class="button small" data-action="selectionpool:dlg-cat-refresh">刷新</button></div>
          ${c.hits.length ? `<div class="spx-cat-hits">${c.hits.map(h => `<button type="button" class="spx-cat-hit" data-action="selectionpool:dlg-cat-hit" data-id="${esc(h.id)}" data-path="${esc(h.path)}"><strong>${esc(h.path)}</strong><em>ID ${esc(h.id)}</em></button>`).join('')}</div>` : ''}
          <div class="spx-cat-cols">${['一级类目', '二级类目', '三级类目'].map((label, i) => `<div class="spx-cat-col"><div class="spx-cat-col-h">${label}</div>
            ${(c.levels[i] || []).length ? c.levels[i].map(node => `<button type="button" class="spx-cat-node ${c.ids[i] === node.id ? 'on' : ''} ${node.leaf ? 'leaf' : ''}" data-action="selectionpool:dlg-cat-pick" data-level="${i}" data-id="${esc(node.id)}" data-name="${esc(node.name)}" data-leaf="${node.leaf ? '1' : ''}">
              <span>${esc(node.name)}</span>${node.leaf ? '' : '<i>›</i>'}${node.authorized === false ? '<em class="spx-unauth">未授权</em>' : ''}</button>`).join('') : `<p class="spx-note">${i === 0 ? '点「刷新」从店铺后台读取类目' : '先选上一级'}</p>`}</div>`).join('')}</div>
        </div>
        <div class="spx-foot"><span class="spx-hint">${picked ? `选中：${esc(picked.path)} · ID ${esc(picked.id)}` : '请选到最后一级（叶子类目）才能保存'}</span>
          <button type="button" class="button small" data-action="selectionpool:dlg-close">取消</button>
          <button type="button" class="button primary small" data-action="selectionpool:dlg-cat-save" ${picked ? '' : 'disabled'}>保存类目</button></div>
      </div></div>`;
    }

    /** 类目弹窗重绘时保留左右列的滚动位置（选三级叶子时上面两列不再跳回顶部）。 */
    function renderKeepCatScroll(skipIndex = -1) {
      const before = [...document.querySelectorAll('.spx-cat-col')].map(col => col.scrollTop);
      render();
      const after = [...document.querySelectorAll('.spx-cat-col')];
      after.forEach((col, index) => {
        if (index === skipIndex) return;
        if (before[index] != null) col.scrollTop = before[index];
      });
    }
    function renderDialogs() {
      if (!ui.name) return '';
      if (ui.name === 'autoShelf') return shelfDialog();
      if (ui.name === 'publication') return publicationDialog();
      if (ui.name === 'manualForm') return formDialog();
      if (ui.name === 'category') return categoryDialog();
      if (ui.name === 'detail') return detailDialog();
      if (ui.name === 'logs') return logsDialog();
      return '';
    }

    // ---------------------------------------------------------------- 动作
    function readFormFields() {
      const out = { attributes: [], categoryId: '', categoryPath: '', warehouseItemId: '' };
      for (const el of document.querySelectorAll('[data-dlg-form]')) out[el.dataset.dlgForm] = String(el.value || '');
      const attrs = ui.form.attributes || [];
      for (const el of document.querySelectorAll('[data-dlg-form-attr]')) {
        const i = Number(el.dataset.dlgFormAttr);
        if (attrs[i]) out.attributes.push({ name: attrs[i].name, value: String(el.value || '') });
      }
      return out;
    }

    async function collectFormFields() {
      const values = readFormFields();
      return api('selectionpool.saveManualParams', {
        itemId: ui.form.itemId, categoryId: values.categoryId, categoryPath: values.categoryPath,
        attributes: values.attributes, warehouseItemId: values.warehouseItemId,
      });
    }

    async function openShop(itemId, reason) {
      if (!state.storeId) { toast('请先在左上角选择店铺', true); return null; }
      try {
        const info = await api('selectionpool.openShopPublishPage', { itemId, storeId: state.storeId, reason: reason || '参数或类目不全，人工在店铺页面补全' });
        if (typeof openShopPage === 'function') await openShopPage(info);
        await reload();
        return info;
      } catch (error) { toast(String(error?.message || error), true); return null; }
    }

    async function handleAction(action, target) {
      if (!String(action).startsWith('selectionpool:dlg-')) return false;
      const cmd = action.slice('selectionpool:dlg-'.length);
      const id = Number(target.dataset.id || 0);
      const value = target.dataset.value;
      switch (cmd) {
        case 'close': close(); return true;
        case 'log-refresh': await refreshLogs(); return true;
        case 'log-open': ui.logs = { ...ui.logs, runId: String(target.dataset.run || '') }; render(); return true;
        case 'log-back': ui.logs = { ...ui.logs, runId: '' }; render(); return true;
        case 'log-copy': {
          const run = (ui.logs.runs || []).find(r => r.runId === ui.logs.runId);
          const text = ((run?.lines || []).map(r => r.line).join('\n')) || '';
          try { await navigator.clipboard.writeText(text); toast(`已复制 ${text ? text.split('\n').length : 0} 行日志`); }
          catch { toast('复制失败，请手动选中日志复制', true); }
          return true;
        }
        case 'detail-tab': ui.detail.tab = ['overview', 'sku', 'params', 'desc', 'reviews', 'source'].includes(value) ? value : 'overview'; render(); return true;
        case 'detail-image': ui.detail.imageIndex = Number(target.dataset.index) || 0; render(); return true;
        case 'detail-refresh': await loadDetail(Number(target.dataset.id || ui.detail.itemId)); return true;
        case 'detail-editor': {
          const editor = window.XXSelectionPoolEditorApi;
          const targetId = Number(target.dataset.id || ui.detail.itemId);
          close();
          if (editor) await editor.load(targetId);
          return true;
        }
        case 'detail-open': {
          const url = String(target.dataset.url || '');
          if (!/^https:\/\//i.test(url)) { toast('这个地址打不开', true); return true; }
          try {
            const result = await api('app.openExternal', { url });
            if (!result?.ok) toast(result?.message || '打不开这个地址', true);
          } catch (error) { toast(String(error?.message || error), true); }
          return true;
        }
        case 'detail-video': {
          const url = String((ui.detail.data?.videos || [])[Number(target.dataset.index)] || '');
          try {
            const result = await api('app.openExternal', { url });
            if (!result?.ok) toast(result?.message || '这个视频没有直链，打不开', true);
          } catch (error) { toast(String(error?.message || error), true); }
          return true;
        }
        case 'shelf-shop': {
          const key = target.dataset.id;
          target.checked ? ui.shelf.shops.add(key) : ui.shelf.shops.delete(key);
          render(); return true;
        }
        case 'shelf-config': {
          const key = target.dataset.key;
          const val = target.type === 'checkbox' ? target.checked : target.value;
          const next = await api('selectionpool.saveAutoShelfConfig', { [key]: val }).catch(() => null);
          if (next) ui.shelf.config = next;
          render(); return true;
        }
        case 'shelf-shopcat-refresh': {
          const result = await api('selectionpool.categoryChildren', { profileId: target.dataset.id, parentId: '', refresh: true }).catch(() => null);
          toast(result?.ok ? `已刷新：${(result.items || []).length} 个一级类目` : (result?.message || '店铺分类暂不可用'), !result?.ok);
          if (result?.ok) {
            ui.shelf.shopCats = { ...ui.shelf.shopCats, [target.dataset.id]: result.items.map(n => ({ id: n.id, name: n.name, path: n.name })) };
            render();
          }
          return true;
        }
        case 'shelf-log-more': ui.shelf.logAll = !ui.shelf.logAll; render(); return true;
        case 'shelf-log-copy': {
          const q = queue();
          const text = ((q.lines || []).length ? q.lines : (ui.shelf.logs || []).map(l => l.line || '')).join('\n');
          try { await navigator.clipboard.writeText(text); toast(`已复制 ${text ? text.split('\n').length : 0} 行日志`); }
          catch { toast('复制失败，请手动选中日志复制', true); }
          return true;
        }
        case 'shelf-shopcat': {
          // 发布页「店铺中分类」：每家店铺分别记住（老软件 next 次自动带出）。
          // 之前只有刷新按钮有分支，选完下拉框不会保存 —— 换了分类下次又变回「未设置」。
          const profileId = String(target.dataset.id || '');
          const picked = String(target.value || '');
          if (!profileId) return true;
          const next = await api('selectionpool.saveAutoShelfConfig', {
            profileId, shopCategories: picked ? [Number(picked)] : [],
          }).catch(() => null);
          if (next) {
            ui.shelf.config = next;
            const row = (ui.shelf.shopCats[profileId] || []).find(o => String(o.id) === picked);
            toast(picked ? `已记住店铺分类：${row?.path || row?.name || picked}` : '已清除店铺分类');
          } else toast('店铺分类保存失败，请重试', true);
          return true;
        }
        case 'shelf-stop': {
          await api('selectionpool.queueStop', {}).catch(() => null);
          toast('已请求停止后续队列（当前这一单会跑完）');
          await refreshShelf(); return true;
        }
        case 'shelf-start': {
          const ids = ui.shelf.itemIds.length ? ui.shelf.itemIds : [];
          const shopIds = [...ui.shelf.shops];
          if (!ids.length) { toast('请先在列表里勾选要上架的选品，再点「查看上架进度」', true); return true; }
          if (!shopIds.length) { toast('请先勾选至少一家已登录的目标店铺', true); return true; }
          ui.busy = true; render();
          try {
            for (const shopId of shopIds) {
              const result = await api('selectionpool.autoShelf', { itemIds: ids, storeId: shopId });
              if (result?.failed && typeof registerManualFixes === 'function') await registerManualFixes(result, false);
            }
            toast('已加入上架队列，可点「后台运行」收起弹窗');
          } catch (error) { toast(String(error?.message || error), true); }
          finally { ui.busy = false; ui.shelf.itemIds = []; await refreshShelf(); }
          return true;
        }
        case 'pub-tab':
          ui.pub.tab = ['failures', 'records', 'logs', 'operators'].includes(value) ? value : 'failures';
          ui.pub.page = 1;
          await refreshPublication();
          return true;
        case 'pub-clear-item':
          ui.pub.itemId = 0;
          render();
          return true;
        case 'pub-query': {
          const el = document.querySelector('[data-dlg-pub-keyword]');
          ui.pub.keyword = String(el?.value || '');
          ui.pub.page = 1;
          if (ui.pub.tab === 'records') render();
          else await refreshPublication();
          return true;
        }
        case 'pub-refresh': await refreshPublication(); return true;
        case 'pub-page': ui.pub.page = Math.max(1, Number(value) || 1); await refreshPublication(); return true;
        case 'pub-expand': ui.pub.expanded = ui.pub.expanded === target.dataset.id ? '' : target.dataset.id; render(); return true;
        case 'pub-copy': {
          const row = (pub().rows || []).find(r => r.id === target.dataset.id);
          const text = row?.diagnostic || row?.message || '';
          try { await navigator.clipboard.writeText(text); toast('已复制排查信息'); }
          catch { toast('复制失败，请展开原因后手动复制', true); }
          return true;
        }
        case 'pub-open-form': open('manualForm', { itemId: id }); return true;
        case 'pub-open-shop': await openShop(id, '从失败记录打开，人工核对并补全'); return true;
        case 'pub-resume': {
          const result = await api('selectionpool.resumeManualShelf', { itemId: id }).catch(error => ({ error: String(error?.message || error) }));
          toast(result?.error ? result.error : (result?.landed ? `已确认入仓 #${result.warehouseItemId}` : '已重新执行上架检查'), Boolean(result?.error));
          await reload(); await refreshPublication(); return true;
        }
        case 'resume-open-shop': await openShop(id, '继续处理没入仓的任务'); return true;
        case 'resume-continue': {
          const result = await api('selectionpool.resumeManualShelf', { itemId: id }).catch(error => ({ error: String(error?.message || error) }));
          toast(result?.error ? result.error : (result?.landed ? `继续入仓成功 #${result.warehouseItemId}` : '已重新执行上架检查'), Boolean(result?.error));
          await reload(); await refreshShelf(); return true;
        }
        case 'form-section': ui.form.section = value || 'basic'; render(); return true;        case 'form-save': {
          const result = await collectFormFields().catch(error => ({ error: String(error?.message || error) }));
          if (result?.error) toast(result.error, true);
          else { toast('补全结果已回写到这条选品'); await loadForm(ui.form.itemId); await reload(); }
          return true;
        }
        case 'form-open-shop': await openShop(ui.form.itemId, '人工补全参数'); return true;
        case 'form-resume': {
          await collectFormFields().catch(() => null);
          const result = await api('selectionpool.resumeManualShelf', { itemId: ui.form.itemId, warehouseItemId: readFormFields().warehouseItemId }).catch(error => ({ error: String(error?.message || error) }));
          toast(result?.error ? result.error : (result?.landed ? `已确认入仓 #${result.warehouseItemId}` : '已重新执行上架检查'), Boolean(result?.error));
          close(); await reload(); return true;
        }
        case 'form-add-attr': {
          const nameEl = document.querySelector('[data-dlg-form-new-name]');
          const valueEl = document.querySelector('[data-dlg-form-new-value]');
          const name = String(nameEl?.value || '').trim(), val = String(valueEl?.value || '').trim();
          if (!name) { toast('请先填参数名', true); return true; }
          ui.form.attributes = [...(ui.form.attributes || []), { name, value: val }];
          render(); return true;
        }
        case 'form-read-category': {
          const result = await api('selectionpool.categoryReadSource', {
            itemId: ui.form.itemId, productId: ui.form.detail?.product?.id,
            platform: ui.form.detail?.product?.platform, storeId: state.storeId, refresh: true,
          }).catch(error => ({ ok: false, message: String(error?.message || error) }));
          if (result?.ok) { toast(`已补读类目 ${result.data?.leafId || ''}`); await loadForm(ui.form.itemId); }
          else toast(result?.message || '没读到类目', true);
          return true;
        }
        case 'form-category': open('category', { itemId: ui.form.itemId }); return true;
        case 'cat-source': ui.cat.profileId = target.value; await loadLevel(0, ''); return true;
        case 'cat-refresh': await loadLevel(0, ''); return true;
        case 'cat-pick': {
          const level = Number(target.dataset.level);
          const ids = ui.cat.ids.slice();
          ids[level] = target.dataset.id;
          for (let i = level + 1; i < 3; i++) ids[i] = '';
          ui.cat.ids = ids;
          if (target.dataset.leaf === '1') {
            const names = [];
            for (let i = 0; i <= level; i++) {
              const node = (ui.cat.levels[i] || []).find(n => n.id === ids[i]);
              if (node) names.push(node.name);
            }
            ui.cat.picked = { id: target.dataset.id, names, path: names.join(' / ') };
            // 选完三级叶子不要让上面两列跳回顶部（用户 2026-11-11）。
            renderKeepCatScroll();
            return true;
          }
          ui.cat.picked = null;
          await loadLevel(level + 1, target.dataset.id);
          const names = [];
          for (let i = 0; i <= level; i++) {
            const node = (ui.cat.levels[i] || []).find(n => n.id === ids[i]);
            if (node) names.push(node.name);
          }
          ui.cat.currentNames = names;
          render(); return true;
        }
        case 'cat-query': {
          const el = document.querySelector('[data-dlg-cat-keyword]');
          ui.cat.keyword = String(el?.value || '');
          const result = await api('selectionpool.categoryLookup', { keyword: ui.cat.keyword }).catch(() => null);
          ui.cat.hits = result?.hits || [];
          if (!ui.cat.hits.length) ui.cat.message = '本机还没读过这个类目；可先在三级列表里逐级展开，或点「刷新」从店铺后台读取。';
          render(); return true;
        }
        case 'cat-hit': {
          ui.cat.picked = { id: target.dataset.id, names: String(target.dataset.path || '').split(' / '), path: target.dataset.path };
          render(); return true;
        }
        case 'cat-save': {
          const result = await api('selectionpool.categorySave', { itemId: ui.cat.itemId, categoryId: ui.cat.picked?.id, categoryPath: ui.cat.picked?.path }).catch(error => ({ error: String(error?.message || error) }));
          if (result?.error) toast(result.error, true);
          else { toast('类目已保存'); if (ui.form.itemId === ui.cat.itemId) await loadForm(ui.cat.itemId); else close(); await reload(); }
          return true;
        }
        case 'personal-login': {
          // 复刻老软件「首页个人淘宝号」：开独立会话登录窗口，登录成功自动关窗。
          const result = await api('personaltaobao.login', {}).catch(error => ({ ok: false, message: String(error?.message || error) }));
          if (result?.ok) toast('已打开个人淘宝号登录窗口，请在窗口里登录（扫码/账号均可），登录成功会自动关闭');
          else toast(result?.message || '打不开登录窗口', true);
          return true;
        }
        case 'cat-read': {
          // 老软件校验 /^\d{6,20}$/：必须把商品 ID 一起传上去，否则必然报「商品 ID 不对」。
          if (!ui.cat.productId) { toast('这条选品还没有商品 ID，请用插件重新采集', true); return true; }
          const result = await api('selectionpool.categoryReadSource', { itemId: ui.cat.itemId, productId: ui.cat.productId, storeId: ui.cat.profileId, refresh: true }).catch(error => ({ ok: false, message: String(error?.message || error) }));
          toast(result?.ok ? `已按商品 ID 补读类目 ${result.data?.leafId || ''}` : (result?.message || '没读到类目'), !result?.ok);
          if (result?.needPersonalLogin) {
            void api('personaltaobao.status', {}).then(s => { ui.cat.personal = Boolean(s?.loggedIn); render(); }).catch(() => undefined);
          }
          if (result?.ok) { close(); await reload(); }
          return true;
        }
        default: return false;
      }
    }

    function handleInput(event) {
      const t = event.target;
      if (!t?.dataset) return false;
      if (t.dataset.dlgPubKeyword !== undefined) { ui.pub.keyword = String(t.value || ''); return true; }
      if (t.dataset.dlgCatKeyword !== undefined) { ui.cat.keyword = String(t.value || ''); return true; }
      if (t.dataset.dlgFormNewName !== undefined || t.dataset.dlgFormNewValue !== undefined) return true;
      if (t.dataset.dlgForm !== undefined || t.dataset.dlgFormAttr !== undefined) return true;
      return false;
    }

    function handleChange(event) {
      const t = event.target;
      if (!t?.dataset) return false;
      const action = t.dataset.action || '';
      if (action === 'selectionpool:dlg-shelf-config' || action === 'selectionpool:dlg-shelf-shop' || action === 'selectionpool:dlg-shelf-shopcat' || action === 'selectionpool:dlg-cat-source' || action === 'selectionpool:dlg-shelf-shopcat-refresh') {
        void handleAction(action, t);
        return true;
      }
      return false;
    }

    // 队列运行时定时刷新进度与日志（老软件弹窗里进度与日志是实时滚的）。
    // 两个细节：① 有输入框正在编辑时不要整块重绘（会抢焦点、丢输入）；
    //          ② 重绘前后保持日志滚动位置（否则日志永远跳回顶部）。
    /**
     * 只更新进度文案和日志节点，不整块重绘 —— 整块重绘会把滚动条拉回第一条（用户 2026-11-12）。
     */
    function applyQueue(q) {
      if (!q || ui.name !== 'autoShelf') return;
      ui.shelf.queue = q;
      if (data()) data().queue = q;
      const logEl = document.querySelector('[data-spx-log]');
      const head = document.querySelector('[data-spx-progress]');
      if (head) head.textContent = `进度 ${Number(q.done) || 0}/${Number(q.total) || 0} · 成功 ${Number(q.ok) || 0} · 失败 ${Number(q.fail) || 0}`;
      const side = document.querySelector('[data-spx-side]');
      if (side) {
        const s = queueSideStats(q);
        const current = side.querySelector('[data-spx-side-current]');
        if (current) current.textContent = s.current;
        const percent = side.querySelector('[data-spx-side-percent]');
        if (percent) percent.textContent = `${s.percent}%`;
        const summary = side.querySelector('[data-spx-side-summary]');
        if (summary) summary.textContent = `上架中 ${s.done}/${s.total} · 成功 ${s.ok} · 失败 ${s.fail}`;
        const bar = side.querySelector('[data-spx-side-bar]');
        if (bar) bar.style.width = `${s.percent}%`;
        const list = side.querySelector('[data-spx-side-list]');
        if (list) {
          const atBottom = list.scrollHeight - list.scrollTop - list.clientHeight < 30;
          const savedTop = list.scrollTop;
          list.innerHTML = s.items.length ? s.items.map((r, i) => queueSideRow(r, i)).join('') : '<div class="spx-side-empty">还没有执行记录。点「开始上架」后，这里会逐件显示排队中、上架中、成功和失败。</div>';
          list.scrollTop = atBottom ? list.scrollHeight : savedTop;
        }
      }
      if (!logEl) return;
      const atBottom = logEl.scrollHeight - logEl.scrollTop - logEl.clientHeight < 40;
      const savedTop = logEl.scrollTop;
      const lines = Array.isArray(q.lines) ? q.lines : [];
      if (!lines.length) return;
      const slice = ui.shelf.logAll ? lines.slice(-600) : lines.slice(-80);
      logEl.innerHTML = slice.map(line => `<div>${esc(line)}</div>`).join('');
      logEl.scrollTop = atBottom ? logEl.scrollHeight : savedTop;
    }

    window.setInterval(() => {
      if (ui.name !== 'autoShelf') return;
      const q = queue();
      if (!q.running) return;
      const active = document.activeElement;
      if (active && active.closest && active.closest('.spx-shelf') && /^(INPUT|TEXTAREA|SELECT)$/.test(active.tagName)) return;
      void api('selectionpool.queueStatus', {}).then(next => {
        if (next) applyQueue(next);
      }).catch(() => undefined);
    }, 2000);

    return { render: renderDialogs, handleAction, handleInput, handleChange, open, close, isOpen, refreshShelf, refreshPublication, applyQueue };
  }

  // 注意：selectionpool.js 的 create() 会在这里挂一个 instance 属性供 editor.js 复用，
  // 所以不能用 Object.freeze——否则写入 instance 时抛 “Cannot add property instance”
  // 会导致 app.js 创建上品库模块时整段 IIFE 崩溃、登录页永久停在「正在自动登录…」。
  window.XXSelectionPoolDialogs = { create };
})();
